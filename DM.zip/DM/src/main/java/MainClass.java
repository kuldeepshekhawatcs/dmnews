import java.util.Date;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dmnews.dao.impl.INewsDao;
import com.dmnews.entity.News;
import com.dmnews.entity.News.LOCATION;


public class MainClass {

	public static void main(String[] args) {
		
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("classpath*:dispatcher-servlet.xml");
	News news = new News();
	news.setLocation(LOCATION.INDORE);
	news.setNewsDate(new Date());
	news.setNewsDespription("In America Trump has won the election");
	news.setNewsHeadLine("The <context:component-scan...> tag will be use to activate Spring MVC annotation scanning capability which allows to make use of annotations like @Controller and @RequestMapping etc.");
	INewsDao dao = (INewsDao)context.getBean("newsDaoImpl");
	System.out.println(dao.findByLocation(LOCATION.valueOf("INDORE")).size());
	
	}	
}
