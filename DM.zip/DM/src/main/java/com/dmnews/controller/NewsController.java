package com.dmnews.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dmnews.dao.impl.INewsDao;
import com.dmnews.entity.News;
import com.dmnews.entity.News.LOCATION;

@Controller
public class NewsController {

	@Autowired
	INewsDao newDao;

	@RequestMapping(value = "/getnews", method = RequestMethod.GET)
	@ResponseBody
	public List<News> getNewsByLocation(@RequestParam("location") String location) {
		return newDao.findByLocation(LOCATION.valueOf(location));
	}


	@RequestMapping(value = "/test", method = RequestMethod.GET)
	@ResponseBody
	String test() {
		System.out.println("Hello world!!!");
		/*News news = new News();
		news.setLocation(LOCATION.INDORE);
		news.setNewsDate(new Date());
		news.setNewsDespription("In India 500 & 1000 ruppess notes are banged!!!!!!!!!!!!!!");
		news.setNewsHeadLine("The <context:component-scan...> tag will be use to activate Spring MVC annotation scanning capability which allows to make use of annotations like @Controller and @RequestMapping etc.");

		newDao.insert(news);*/
		return "index";
	}
	
}
