package com.dmnews.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.dmnews.entity.News;


public interface INewsDao {

	public void insert(News news);
	public List<News> findAll();
	public List<News> findByLocation(Enum location);
}
