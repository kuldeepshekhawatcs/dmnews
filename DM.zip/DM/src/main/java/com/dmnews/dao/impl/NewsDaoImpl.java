package com.dmnews.dao.impl;

import java.util.List;





import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;




import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dmnews.entity.News;

@Repository("newsDaoImpl")
@Transactional
public class NewsDaoImpl implements INewsDao{

	@Autowired
	private SessionFactory sessionFactory ;
	
	
	public void insert(News news) {
		sessionFactory.getCurrentSession().save(news);
		
		
	} 
	
	public List<News> findAll() {
		 return sessionFactory.getCurrentSession().createQuery("FROM News").list();
	}

	public List<News> findByLocation(Enum location) {
		return sessionFactory.getCurrentSession().getNamedQuery("findByLocation").setParameter("location", location).list();
	} 
	
}
