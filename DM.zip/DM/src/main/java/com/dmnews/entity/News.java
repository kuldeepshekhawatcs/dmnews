package com.dmnews.entity;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;

import org.hibernate.annotations.NamedQueries;

import com.fasterxml.jackson.annotation.JsonIgnore;


@NamedQueries({@org.hibernate.annotations.NamedQuery(name="findByLocation",query="select n from News n where n.location =:location order by newsDate desc")})                   

@Entity
public class News {

	@Id
	@GeneratedValue
	private int id;
	@Column
	private String newsHeadLine;
	
	@Column
	private String newsDespription;
	
	@Column
	private Date newsDate;
	
	@Column
	private LOCATION location;
	
	@JsonIgnore
	@Column
	@Lob
	private Blob image;
	

	public Blob getImage() {
		return image;
	}


	public void setImage(Blob image) {
		this.image = image;
	}


	public enum LOCATION {
		INDORE, DEWAS
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNewsHeadLine() {
		return newsHeadLine;
	}


	public void setNewsHeadLine(String newsHeadLine) {
		this.newsHeadLine = newsHeadLine;
	}


	public String getNewsDespription() {
		return newsDespription;
	}


	public void setNewsDespription(String newsDespription) {
		this.newsDespription = newsDespription;
	}


	public Date getNewsDate() {
		return newsDate;
	}


	public void setNewsDate(Date newsDate) {
		this.newsDate = newsDate;
	}

	@Enumerated(EnumType.STRING)
	public LOCATION getLocation() {
		return location;
	}


	public void setLocation(LOCATION location) {
		this.location = location;
	}
}
