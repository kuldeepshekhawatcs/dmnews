myController.controller('newsController',function($scope)
		{
		alert("adfa");
		}	
	);
