var myApp = angular.module('myApp', ['ngRoute','myController','ngResource']);

var myController = angular.module('myController',[]);

var myServices = angular.module('myServices', []);



myApp.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "html/News.html",
        controller: 'newsController'
        
    })
    .when("/red", {
        templateUrl : "html/News.html"
    })
    .when("/green", {
        templateUrl : "green.htm"
    })
    .when("/blue", {
        templateUrl : "blue.htm"
    });
});